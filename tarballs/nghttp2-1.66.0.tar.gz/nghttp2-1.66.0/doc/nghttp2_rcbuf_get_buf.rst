
nghttp2_rcbuf_get_buf
=====================

Synopsis
--------

*#include <nghttp2/nghttp2.h>*

.. function:: nghttp2_vec nghttp2_rcbuf_get_buf(nghttp2_rcbuf *rcbuf)

    
    Returns the underlying buffer managed by *rcbuf*.
