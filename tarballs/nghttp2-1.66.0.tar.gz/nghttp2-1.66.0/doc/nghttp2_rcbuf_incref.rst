
nghttp2_rcbuf_incref
====================

Synopsis
--------

*#include <nghttp2/nghttp2.h>*

.. function:: void nghttp2_rcbuf_incref(nghttp2_rcbuf *rcbuf)

    
    Increments the reference count of *rcbuf* by 1.
