
nghttp2_is_fatal
================

Synopsis
--------

*#include <nghttp2/nghttp2.h>*

.. function:: int nghttp2_is_fatal(int lib_error_code)

    
    Returns nonzero if the :type:`nghttp2_error` library error code
    *lib_error* is fatal.
