#assert('TCPSocket.gethostbyname') do
#assert('TCPSocket.new') do
#assert('TCPSocket#close') do
#assert('TCPSocket#write') do
